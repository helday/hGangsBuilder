
local GangsData = {}

function GetGangs()
	local data = LoadResourceFile('hGangsBuilder', 'data/gangData.json')
	return data and json.decode(data) or {}
end

function SaveGang(data)
	local Gang = {}

	table.insert(Gang, {
		gangInfos = {
			gangName = data.Name,
			gangLabel = data.Label
		},
		gangBlip = {
			blipcoords = json.encode(data.Blips[1].Position),
			zone = data.Blips[1].Zone,
			bliplabel = data.Blips[1].Label,
			blipsprite = data.Blips[1].Sprite,
			blipcouleur = data.Blips[1].Couleur,
			bliptaille = data.Blips[1].Taille,
		},
		gangPoints = {
			pointvestiaire = json.encode(data.Vestiaire),
			pointgarage = json.encode(data.Garage),
			pointcoffre = json.encode(data.Coffre),
			pointboss = json.encode(data.Boss),
			pointspawnveh = json.encode(data.SpawnVeh),
			headingspawnveh = json.encode(data.HeadingVeh),
			pointrangementveh = json.encode(data.RangeVeh),
		},
		gangCoffre = {
			blackMoney = 0,
			items = {},
			weapons = {}
		}
	})

	Wait(50)
	SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gang, {indent=true}), -1)
	Wait(50)
	TriggerClientEvent("hGangsBuilder:NewGang", -1, GetGangs())
end

RegisterServerEvent("hGangsBuilder:AddGang")
AddEventHandler("hGangsBuilder:AddGang", function(data)
	if Config.UseJob2 then
		for k,v in pairs(data.Grades) do
			MySQL.Async.execute([[
				INSERT INTO `job2_grades` (`job2_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
					(@gangName, @gradeId, @gradeName, @gradeLabel, @gradeSalaire, '{}', '{}')
				;
			]], {
				['@gangName'] = data.Name,
				['@gradeId'] = k-1,
				['@gradeName'] = v.name,
				['@gradeLabel'] = v.label,
				['@gradeSalaire'] = v.salaire
			})
		end
	
		MySQL.Async.execute([[
			INSERT INTO `addon_account` (name, label, shared) VALUES (@gangSociety, @gangLabel, 1);
			INSERT INTO `addon_inventory` (name, label, shared) VALUES (@gangSociety, @gangLabel, 1);
			INSERT INTO `datastore` (name, label, shared) VALUES (@gangSociety, @gangLabel, 1);
			INSERT INTO `jobs2` (`name`, `label`) VALUES (@gangName, @gangLabel);
		]], {
			['@gangName'] = data.Name,
			['@gangLabel'] = data.Label,
			['@gangSociety'] = "society_"..data.Name
		}, function()
			print("Nouveau Gang: "..data.Label)
	
			SaveGang(data)
		end)
	else
		for k,v in pairs(data.Grades) do
			MySQL.Async.execute([[
				INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
					(@gangName, @gradeId, @gradeName, @gradeLabel, @gradeSalaire, '{}', '{}')
				;
			]], {
				['@gangName'] = data.Name,
				['@gradeId'] = k-1,
				['@gradeName'] = v.name,
				['@gradeLabel'] = v.label,
				['@gradeSalaire'] = v.salaire
			})
		end
	
		MySQL.Async.execute([[
			INSERT INTO `addon_account` (name, label, shared) VALUES (@gangSociety, @gangLabel, 1);
			INSERT INTO `addon_inventory` (name, label, shared) VALUES (@gangSociety, @gangLabel, 1);
			INSERT INTO `datastore` (name, label, shared) VALUES (@gangSociety, @gangLabel, 1);
			INSERT INTO `jobs` (`name`, `label`) VALUES (@gangName, @gangLabel);
		]], {
			['@gangName'] = data.Name,
			['@gangLabel'] = data.Label,
			['@gangSociety'] = "society_"..data.Name
		}, function()
			print("Nouveau Gang: "..data.Label)
	
			SaveGang(data)
		end)
	end
end)

ESX.RegisterServerCallback("hGangsBuilder:GetGangs", function(src, cb)
	local Gangs = GetGangs()

	cb(Gangs)
end)