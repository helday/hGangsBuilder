
ESX.RegisterCommand("gangsbuilder", { "admin", "superadmin", "owner" }, function(xPlayer)
    xPlayer.triggerEvent("hGangsBuilder:OpenMenu")
end)

function RefreshGangs()
    local Gangs = GetGangs()

    TriggerClientEvent("hGangsBuilder:RefreshGangs", -1, Gangs)
end

RegisterServerEvent("hGangsBuilder:DeposeMoney")
AddEventHandler("hGangsBuilder:DeposeMoney", function(gangName, Amount)
    local xPlayer = ESX.GetPlayerFromId(source)
	local Gangs = GetGangs()

    if xPlayer.getAccount('black_money').money >= Amount then
        for k,v in pairs(Gangs) do
            if v.gangInfos.gangName == gangName then
                v.gangCoffre.blackMoney = v.gangCoffre.blackMoney + Amount
                xPlayer.removeAccountMoney('black_money', Amount)
                SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                Wait(50)
                RefreshGangs()
            end
        end
    else
        xPlayer.showNotification("Vous n'avez pas assez d'argent sale sur vous !")
    end
end)

RegisterServerEvent("hGangsBuilder:RetireMoney")
AddEventHandler("hGangsBuilder:RetireMoney", function(gangName, Amount)
    local xPlayer = ESX.GetPlayerFromId(source)
	local Gangs = GetGangs()

	for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if v.gangCoffre.blackMoney >= Amount then
                v.gangCoffre.blackMoney = v.gangCoffre.blackMoney - Amount
                xPlayer.addAccountMoney('black_money', Amount)
                SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                Wait(50)
                RefreshGangs()
            else
                xPlayer.showNotification("Le gang n'a pas assez d'argent sale !")
            end
		end
	end
end)

local Jobs = {}
local Jobs2 = {}

MySQL.ready(function()
	local result = MySQL.Sync.fetchAll('SELECT * FROM jobs', {})

	for i=1, #result, 1 do
		Jobs[result[i].name]        = result[i]
		Jobs[result[i].name].grades = {}
	end

	local result2 = MySQL.Sync.fetchAll('SELECT * FROM job_grades', {})

	for i=1, #result2, 1 do
		Jobs[result2[i].job_name].grades[tostring(result2[i].grade)] = result2[i]
	end

    if Config.UseJob2 then

        local result3 = MySQL.Sync.fetchAll('SELECT * FROM jobs2', {})

        for i=1, #result3, 1 do
            Jobs2[result3[i].name]        = result3[i]
            Jobs2[result3[i].name].grades = {}
        end
    
        local result4 = MySQL.Sync.fetchAll('SELECT * FROM job2_grades', {})
    
        for i=1, #result4, 1 do
            Jobs2[result4[i].job2_name].grades[tostring(result4[i].grade)] = result4[i]
        end
    end
end)

ESX.RegisterServerCallback("hGangsBuilder:GetMembres", function(source, cb, gangName)
    if not Config.UseJob2 then
        MySQL.Async.fetchAll('SELECT firstname, lastname, identifier, job, job_grade FROM users WHERE job = @job ORDER BY job_grade DESC', {
            ['@job'] = gangName
        }, function (results)
            local membres = {}
    
            for i=1, #results, 1 do
                table.insert(membres, {
                    name       = results[i].firstname .. ' ' .. results[i].lastname,
                    identifier = results[i].identifier,
                    job = {
                        name        = results[i].job,
                        label       = Jobs[results[i].job].label,
                        grade       = results[i].job_grade,
                        grade_name  = Jobs[results[i].job].grades[tostring(results[i].job_grade)].name,
                        grade_label = Jobs[results[i].job].grades[tostring(results[i].job_grade)].label
                    },
                })
            end
    
            cb(membres)
        end)
    else
        MySQL.Async.fetchAll('SELECT firstname, lastname, identifier, job2, job2_grade FROM users WHERE job2 = @job2 ORDER BY job2_grade DESC', {
            ['@job2'] = gangName
        }, function (results)
            local membres = {}
    
            for i=1, #results, 1 do
                table.insert(membres, {
                    name       = results[i].firstname .. ' ' .. results[i].lastname,
                    identifier = results[i].identifier,
                    job2 = {
                        name        = results[i].job2,
                        label       = Jobs2[results[i].job2].label,
                        grade       = results[i].job2_grade,
                        grade_name  = Jobs2[results[i].job2].grades[tostring(results[i].job2_grade)].name,
                        grade_label = Jobs2[results[i].job2].grades[tostring(results[i].job2_grade)].label
                    },
                })
            end
    
            cb(membres)
        end)
    end
end)

RegisterNetEvent("hGangsBuilder:setJob")
AddEventHandler("hGangsBuilder:setJob", function(PlayerId, identifier, job, NewGrade, Type)
	local xPlayer = ESX.GetPlayerFromId(source)

	if identifier ~= nil and PlayerId == nil then
		xTarget = ESX.GetPlayerFromIdentifier(identifier)

		if xTarget then
			if Type == 'Recruter' then
				if ESX.DoesJobExist(job, NewGrade) then
					xTarget.setJob(job, NewGrade)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Promouvoir' then
				if ESX.DoesJobExist(job, NewGrade) then
					xTarget.setJob(job, NewGrade)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Virer' then
				xTarget.setJob('unemployed', '0')
			end
		end
	else
		xTarget = ESX.GetPlayerFromId(PlayerId)

		if xTarget then
			if Type == 'Recruter' then
				if ESX.DoesJobExist(job, NewGrade) then
					xTarget.setJob(job, NewGrade)
		
					xTarget.showNotification("Vous avez un Nouveau Job: ~r~"..xTarget.getJob().label.." ~s~- ~r~"..xTarget.getJob().grade_label)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Promouvoir' then
				if ESX.DoesJobExist(job, NewGrade) then
					xTarget.setJob(job, NewGrade)
	
					xTarget.showNotification("Vous avez un Nouveau Grade: ~r~"..xTarget.getJob().label.." ~s~- ~r~"..xTarget.getJob().grade_label)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Virer' then
				xTarget.setJob('unemployed', '0')
				xTarget.showNotification("Vous avez été Virer des: ~r~"..job)
			end
		end
	end
end)

RegisterNetEvent("hGangsBuilder:setJob2")
AddEventHandler("hGangsBuilder:setJob2", function(PlayerId, identifier, job, NewGrade, Type)
	local xPlayer = ESX.GetPlayerFromId(source)

	if identifier ~= nil and PlayerId == nil then
		xTarget = ESX.GetPlayerFromIdentifier(identifier)

		if xTarget then
			if Type == 'Recruter' then
				if ESX.DoesJob2Exist(job, NewGrade) then
					xTarget.setJob2(job, NewGrade)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Promouvoir' then
				if ESX.DoesJob2Exist(job, NewGrade) then
					xTarget.setJob2(job, NewGrade)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Virer' then
				xTarget.setJob2('unemployed', '0')
			end
		end
	else
		xTarget = ESX.GetPlayerFromId(PlayerId)

		if xTarget then
			if Type == 'Recruter' then
				if ESX.DoesJob2Exist(job, NewGrade) then
					xTarget.setJob2(job, NewGrade)
		
					xTarget.showNotification("Vous avez un Nouveau Job: ~r~"..xTarget.getJob().label.." ~s~- ~r~"..xTarget.getJob().grade_label)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Promouvoir' then
				if ESX.DoesJob2Exist(job, NewGrade) then
					xTarget.setJob2(job, NewGrade)
	
					xTarget.showNotification("Vous avez un Nouveau Grade: ~r~"..xTarget.getJob().label.." ~s~- ~r~"..xTarget.getJob().grade_label)
				else
					xPlayer.showNotification("~o~Ce Grade n'existe pas !")
				end
			elseif Type == 'Virer' then
				xTarget.setJob2('unemployed', '0')
				xTarget.showNotification("Vous avez été Virer des: ~r~"..job)
			end
		end
	end
end)

ESX.RegisterServerCallback("hGangsBuilder:GetMyInventory", function(src, cb)
    local xPlayer = ESX.GetPlayerFromId(src)

    local inventory = xPlayer.getInventory()

    cb(inventory)
end)

ESX.RegisterServerCallback("hGangsBuilder:GetGangInventory", function(src, cb, gangName)
    local Gangs = GetGangs()
    local inventory = {}

    for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if next(v.gangCoffre.items) then
                inventory = v.gangCoffre.items
            end
        end
    end
    
    cb(inventory)
end)


ESX.RegisterServerCallback("hGangsBuilder:GetMyLoadout", function(src, cb)
    local xPlayer = ESX.GetPlayerFromId(src)

    local loadout = xPlayer.getLoadout()

    cb(loadout) 
end)

ESX.RegisterServerCallback("hGangsBuilder:GetGangLoadout", function(src, cb, gangName)
    local Gangs = GetGangs()
    local loadout = {}

    for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if next(v.gangCoffre.weapons) then
                loadout = v.gangCoffre.weapons
            end
        end
    end
    
    cb(loadout)
end)

RegisterNetEvent("hGangsBuilder:DeposeItem")
AddEventHandler("hGangsBuilder:DeposeItem", function(gangName, item)
    local Gangs = GetGangs()
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem(item.name, 1)

	for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if next(v.gangCoffre.items) then
                for _,j in pairs(v.gangCoffre.items) do
                    if j.name == item.name then
                        j.count = j.count + 1
    
                        SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                        Wait(50)
                        RefreshGangs()

                        return
                    end
                end

                table.insert(v.gangCoffre.items, {
                    name = item.name,
                    label = item.label,
                    count = 1
                })

                SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                Wait(50)
                RefreshGangs()
            else
                table.insert(v.gangCoffre.items, {
                    name = item.name,
                    label = item.label,
                    count = 1
                })

                SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                Wait(50)
                RefreshGangs()
            end
		end
	end
end)

RegisterNetEvent("hGangsBuilder:RetireItem")
AddEventHandler("hGangsBuilder:RetireItem", function(gangName, item)
    local Gangs = GetGangs()
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeInventoryItem(item.name, 1)

	for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if next(v.gangCoffre.items) then
                for _,j in pairs(v.gangCoffre.items) do
                    if j.name == item.name then
                        j.count = j.count - 1
    
                        SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                        Wait(50)
                        RefreshGangs()

                        return
                    end
                end
            end
		end
	end
end)

RegisterNetEvent("hGangsBuilder:DeposeWeapon")
AddEventHandler("hGangsBuilder:DeposeWeapon", function(gangName, weapon)
    local Gangs = GetGangs()
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.removeWeapon(weapon.name)

	for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if next(v.gangCoffre.weapons) then
                for _,j in pairs(v.gangCoffre.weapons) do
                    if j.name == weapon.name then
                        j.count = j.count + 1
    
                        SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                        Wait(50)
                        RefreshGangs()

                        return
                    end
                end

                table.insert(v.gangCoffre.weapons, {
                    name = weapon.name,
                    label = weapon.label,
                    ammo = weapon.ammo,
                    count = 1
                })

                SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                Wait(50)
                RefreshGangs()
            else
                table.insert(v.gangCoffre.weapons, {
                    name = weapon.name,
                    label = weapon.label,
                    ammo = weapon.ammo,
                    count = 1
                })

                SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                Wait(50)
                RefreshGangs()
            end
		end
	end
end)


RegisterNetEvent("hGangsBuilder:RetireWeapon")
AddEventHandler("hGangsBuilder:RetireWeapon", function(gangName, weapon)
    local Gangs = GetGangs()
    local xPlayer = ESX.GetPlayerFromId(source)

    xPlayer.addWeapon(weapon.name, weapon.ammo)

	for k,v in pairs(Gangs) do
		if v.gangInfos.gangName == gangName then
            if next(v.gangCoffre.weapons) then
                for _,j in pairs(v.gangCoffre.weapons) do
                    if j.name == weapon.name then
                        j.count = j.count - 1
    
                        SaveResourceFile('hGangsBuilder', 'data/gangData.json', json.encode(Gangs, {indent=true}), -1)
                        Wait(50)
                        RefreshGangs()

                        return
                    end
                end
            end
		end
	end
end)

RegisterNetEvent("hGangsBuilder:Ligote")
AddEventHandler("hGangsBuilder:Ligote", function(player)
    TriggerClientEvent("hGangsBuilder:Ligote", player)
end)

RegisterNetEvent("hGangsBuilder:Kidnapper")
AddEventHandler("hGangsBuilder:Kidnapper", function(player)
    TriggerClientEvent("hGangsBuilder:Kidnapper", player, source)
end)

RegisterNetEvent("hGangsBuilder:MettreSortirVehicule")
AddEventHandler("hGangsBuilder:MettreSortirVehicule", function(player)
    TriggerClientEvent("hGangsBuilder:MettreSortirVehicule", player)
end)