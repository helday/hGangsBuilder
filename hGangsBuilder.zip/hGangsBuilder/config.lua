Config = {}

Config.UseJob2 = false

Config.Vehicules = {
    ['ballas'] = {
        { name = 'buffalo', label = 'Buffalo' }
    }
}

Config.VehiculesColors = {
    ['ballas'] = {
        { r = 0, g = 0, b = 0 }
    }
}


Config.Tenues = {
    ['ballas'] = {
        {
            tshirt_1 = 0,
            tshirt_2 = 0,
            torso_1  = 0,
            torso_2  = 0,
            arms     = 0,
            arms_2   = 0,
            pants_1  = 0,
            pants_2  = 0,
            shoes_1  = 0,
            shoes_2  = 0
        }
    }
}